# MeSH Search Query Tool: Automated Systematic Review Query Generator
#### Video Demo: [https://www.youtube.com/watch?v=p3HxQOuU5bM](https://www.youtube.com/watch?v=p3HxQOuU5bM)
#### Description:

The **MeSH Search Query Tool** is a web application that helps researchers create search queries for systematic reviews. When doing medical research, authors need to search databases like PubMed, Embase, and Cochrane using a specific format. This usually requires using "Medical Subject Headings" (MeSH) and combining many different synonyms with "AND" and "OR" logic. Doing this by hand takes a long time and it is easy to make mistakes. This tool tries to make that process easier by using an AI model to find the main parts of a question and then looking up synonyms in medical databases.

The tool works in steps. First, it takes a research question and uses an AI model (via NanoGPT) to identify the "PICO" elements (Population, Intervention, Comparison, and Outcome). Second, it connects to official medical databases (MeSH and UMLS) to find related terms and synonyms. Finally, it writes the actual search strings for different databases automatically. This makes sure that the syntax, like brackets and proximity markers, is correct for each specific website.

### Files and Their Purpose

The code is split into several files to keep things organized:

- **`app.py`**: This is the main file that runs the user interface using Streamlit. It handles the different steps of the process and keeps track of the data while the user moves through the app. It also manages how API keys are saved and loaded.
- **`src/models.py`**: This file contains the data structures used by the app. It defines what a "Database" is or what an "Extracted Concept" should look like. Using this file ensures that the data stays consistent between the interface and the logic.
- **`src/mesh_loader.py`**: This file handles the official MeSH database (a large XML file). It includes code to search for headings and find "child" terms in the medical hierarchy so the search can be broader.
- **`src/umls_loader.py`**: This file manages local data from the UMLS system. Because the raw data is very large, this script turns it into a smaller format (Parquet) that the app can read quickly without lagging.
- **`src/keyword_extractor.py`**: This part talks to the AI model. It provides instructions to the AI to help it find keywords in the research question. It also tries to separate "core" drugs from "modifiers" like dose or route.
- **`src/query_builder.py`**: This is the part that writes the final search strings. Since PubMed uses different symbols than Embase or Scopus, this file has the specific rules for each one.
- **`src/api_clients.py`**: This file handles connections to online services like the UMLS API. It includes a "rate limiter" to make sure the app doesn't send too many requests too fast, which could get the user's key blocked.
- **`build.py` and `launcher.py`**: These are helper scripts used to turn the Python code into a standalone program that can be run on a computer without installing Python.
- **`run.sh`**: A simple script to start the application with one command.

### Design Choices

I made several choices while building this tool to make it more useful for researchers:

1. **Using AI for Keyword Finding**: I used an AI model because medical questions can be written in many ways. Simple text-matching often misses the context, but an AI (like GPT) is good at understanding which words are part of the "Category" or "Intervention".
2. **Local and API Options**: The app can either use local files on the computer or connect to an online API. I did this because the medical databases are very large (several gigabytes). Some users might prefer to download them once for speed, while others might prefer the API to save space.
3. **Handling Specific Terms**: In the `keyword_extractor.py` file, I added logic to search for simpler terms if a complex one isn't found. For example, if "Intravenous Penicillin" isn't in the database, the tool will try to find just "Penicillin". This keeps the search from stopping when a term is too specific.
4. **Keeping the Logic Simple**: Scientific searches can get very messy with too many parentheses. I designed the code to group terms in a very specific order so that the search results are accurate. This prevents the common problem where "OR" and "AND" get mixed up.
5. **Streamlit UI**: I chose Streamlit for the interface because it is straightforward for users. It allows for a multi-step workflow where researchers can check the AI's work and edit the synonyms before the final search string is made. This "human-in-the-loop" approach is important for scientific accuracy.
6. **Package Management with UV**: I used `uv` to manage the project's dependencies. Since this tool uses several large libraries (like Pydantic, Pandas, and Streamlit), `uv` helps keep the environment stable and makes installation very fast. It also ensures that the exact versions of the libraries I used are locked in the `uv.lock` file, so the app will work the same way for everyone who runs it.

This project was built to solve a real problem in medical research. While it won't replace a human librarian, it should help researchers get a head start on their search strategies.
