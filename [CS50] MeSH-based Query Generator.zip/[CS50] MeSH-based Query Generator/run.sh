#!/bin/bash
# Start the Streamlit app

cd "$(dirname "$0")"
uv run --active streamlit run app.py
